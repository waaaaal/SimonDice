
package poo;


public enum tColores {

    ROJO, VERDE, AZUL , DORADO, BLANCO, MARRON, NARANJA;




}