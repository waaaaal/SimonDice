package poo;

import java.io.IOException;
import java.util.Scanner;

public class NewMain {

    public static void main(String[] args) throws IOException {
        Engine engine = new Engine();
        engine.start();


    }



}
